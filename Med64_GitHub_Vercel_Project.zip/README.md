# Med64 Exam Portal

## Deploy with GitHub + Vercel
1. Upload `index.html` and `questions.json` to the same GitHub repository folder.
2. Import that GitHub repository into Vercel.
3. Deploy.
4. To change the built-in questions, edit `questions.json` on GitHub and push the change. Vercel will redeploy automatically.

The website still supports manual JSON import, section selection, custom question count, and time limits.
